import requests
from dotenv import load_dotenv
import os
import sys
import psycopg2

userid = sys.argv[1]
try:
    #get .env from remote
    envfromweb = requests.get("http://proto.scranfyp.site/env/.env")

    #write to .env
    with open(".env", "wb") as f:
        f.write(envfromweb.content)
    #load .env
    load_dotenv()
    #remove .env 
    os.remove(".env")

except:
    #error handling for loading database parameters
    print("Failed to load database parameters")

dbparams = os.getenv("DB_PARAMS")

#error handling for database connection
try:
    db = psycopg2.connect (dbparams)
except:
    print("I am unable to connect to the database")

# create a cursor object using the cursor() method
cur = db.cursor()

# execute the query
cur.execute("""UPDATE targets set elearncomplete = TRUE where user_id = %s""", (userid))
    

