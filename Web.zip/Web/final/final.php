<?php
exec("python phishermancomplete.py " . $_COOKIE['userid']);
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Header  -->
    <title>PhisherMan Training</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
</head>
<body>
    <!-- Training content  -->
    <div id="message">
        <p>You did it!</p>
    </div>

    <div id="message-body">
        <p>You have now completed the course. Thank you for your time. You may now close this window.</p>
    </div>

    <div id="bottom-bar">
        <!-- bottom bar, next and previous buttons  -->
        <button id="next-button" onclick="window.location.href='welcome.html'">Back</button>
        <button id="next-button" onclick="window.location.href='pg2.html'">Next</button>
    </div>

</body>
</html>